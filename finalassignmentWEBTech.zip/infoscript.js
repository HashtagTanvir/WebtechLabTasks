function NameValidation(){
	var n=document.getElementById('nid').value;
	if(n == ""){
		alert('Name cannot be empty');
	}
	
	
}
function EmailValidation(){
	var e=document.getElementById('eid').value;
	if(e == ""){
		alert('Email cannot be empty');
	}
	
}
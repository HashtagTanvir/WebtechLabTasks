<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: gray;">
	<table style="border: none; width: 1000px;">
			<tr>
				<td></td>
				<td style="width: 650px; text-align: center; border: solid; border-color: skyblue; background-color: white;">
					<h3 style="color: green;"><i>Name: </i>Tanvir Ahmed</h3>
					<h3 style="color: green;"><i>Gmail: </i>lm10@gmail.com</h3>
					<h3 style="color: green;"><i>Phone: </i>01779825746</h3>
					<h3 style="color: green;"><i>City: </i>Dhaka</h3>
					<h3 style="color: green;"><i>Street: </i>Uttara</h3>
					<h3 style="color: green;"><i>Sector: </i>9</h3>
					<h3 style="color: green;"><i>House Number: </i>h9</h3>
					<a href="adminsettings.php"><input type="button" name="backtoprev" value="Back"  style="width: 200px; font-size: 15px; background-color: blue"/></a>
					<form method="post" action="blockedcustomer.php">
						<input type="submit" name="blockcustomer" value="Block" style="width: 200px; font-size: 15px; background-color: red;"/>
					</form>
				</td>
			</tr>
		</table>
</body>
</html>

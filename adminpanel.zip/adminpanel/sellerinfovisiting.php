<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: gray;">
	<form method="post" action="selleradding.php">
		<table style="border: none; width: 1000px;">
			<tr>
				<td></td>
				<td style="width: 650px; text-align: center; border: solid; border-color: skyblue; background-color: white;">
					<h5><input type="text" name="sellername" placeholder="seller name" style="width: 250px" /></h5>
					<h5><input type="text" name="sellerid" placeholder="seller id no" style="width: 250px" /></h5>
					<h5><input type="text" name="sellerpass" placeholder="seller password" style="width: 250px" /></h5>
					<h5><input type="text" name="selleraddress" placeholder="seller address"style="width: 250px;" /></h5>
					<h5><input type="text" name="sellerphone" placeholder="seller Phone"style="width: 250px;" /></h5>
					<h5><input type="file" name="sellerimg"/><br/><b style="color: green;">Seller Image</b></h5>
					<a href="adminsettings.php"><input type="button" name="backtoprev" value="Back"  style="width: 250px; font-size: 20px; background-color: blue"/></a>
					<br/>
					<input type="submit" name="addseller" value="Add" style="width: 250px; background-color: green;font-size: 20px" />

				</td>
			</tr>
		</table>
	</form>
</body>
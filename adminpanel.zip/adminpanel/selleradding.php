<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
	if(isset($_REQUEST['addseller'])){
		$name=trim($_REQUEST['sellername']);
		$id=trim($_REQUEST['sellerid']);
		$pass=trim($_REQUEST['sellerpass']);
		$adrs=trim($_REQUEST['selleraddress']);
		$pn=trim($_REQUEST['sellerphone']);
		$img=trim($_REQUEST['sellerimg']);
		if(empty($name) == true || empty($id) == true || empty($pass)==true||empty($adrs)==true||empty($pn)==true||empty($img)==true){
			echo "null submission";
		}
		else{
			echo "Added successfully";
		}
	}
?>
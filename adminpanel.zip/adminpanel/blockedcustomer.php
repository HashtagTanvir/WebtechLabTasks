<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
	if(isset($_POST['blockcustomer'])){
		echo "Successfully Blocked";
	}
?>

<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table style="border: none; width: 1000px;">
			<tr>
				<td></td>
				<td style="width: 650px; text-align: center; border: solid; border-color: skyblue; background-color: white;">
					
				</td>
			</tr>
		</table>
</body>
</html>
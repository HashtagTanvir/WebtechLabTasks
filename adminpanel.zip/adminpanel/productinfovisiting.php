<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: gray;">
	<form method="get" action="productinfovisiting.php">
		<table style="border: none; width: 1000px;">
			<tr>
				<td></td>
				<td style="width: 650px; text-align: center; border: solid; border-color: skyblue; background-color: white;">
					<h5><input type="text" name="productname" placeholder="product name" style="width: 250px" /></h5>
					<h5><input type="text" name="productslno" placeholder="product serial no" style="width: 250px" /></h5>
					<h5><input type="file" name="productimg"/><br/><b style="color: green;">Product Image</b></h5>
					<a href="adminsettings.php"><input type="button" name="backtoprev" value="Back"  style="width: 250px; font-size: 20px; background-color: blue"/></a>
					<br/>
					<input type="submit" name="saveproduct" value="Save" style="width: 250px; background-color: green;font-size: 20px" />

				</td>
			</tr>
		</table>
	</form>
	<table style="border: none; width: 1000px;">
			<tr>
				<td></td>
				<td style="width: 650px; text-align: center; border: solid; border-color: skyblue; background-color: white;">
					<h3 style="color: green;"><i>Output:</i></h3>
					<?php
					if(isset($_GET['saveproduct'])){
						$name=$_GET['productname'];
						$slno=$_GET['productslno'];
						$img=$_GET['productimg'];
						echo '<b style="color: blue">Product Name: </b>'.$name."<br/>";
						echo '<b style="color: blue">Product Serial: </b>'.$slno."<br/>";
						echo '<b style="color: blue">Product Image: </b>'.$img."<br/>";
					}

					?>
				</td>
			</tr>
		</table>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Site</title>
</head>
<body style="background-color: gray;" >
	<div style="background-color: none; text-align: center ;padding: 15px">
		<b style="font-size: 50px; color: black">This Is Admin Panel</b>
	</div>
	<form method="post" action="adminvalidation.php">
			<table style="border: none; width :1000px; padding: 15px; text-align: right">	
		
			<tr>
				<td style="width: 500px; border: none;"></td>
				<td style="border: solid; width: 500px; text-align: center; padding: 15px; color: black; border-color: skyblue; background-color: white">
					<h5>Sign In with your ID And Password</h5>
					<h6><input type="text" name="adminid"  placeholder="id" /></h6>
					<input type="passwords" name="adminpass" placeholder="password" /><br/>
					<h4><input type="submit" name="adminloginbutton" value="Log In"/> <a href="adminsignup.php" style="text-decoration: none;"/>sign up</a></h4>
					
				</td>
			</tr>

		
			</table>
		
	</form>
	
</body>
</html>
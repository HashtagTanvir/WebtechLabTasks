<!DOCTYPE html>
<html>
<head>
	<title>Admin Site</title>
</head>
<body style="background-color: gray;" >
	<div style="background-color: none; text-align: center ;padding: 15px">
		<b style="font-size: 50px; color: black">This Is Admin Panel</b>
	</div>
	<form method="post" action="adminvalidation.php">
			<table style="border: none; width :1000px; padding: 15px; text-align: right">	
		
			<tr>
				<td style="width: 500px; border: none;"></td>
				<td style="border: solid; width: 500px; text-align: center; padding: 15px; color: black; border-color: skyblue; background-color: white">
					
					<h6><input type="text" name="adminid" placeholder="id" /></h6>
					<h6><input type="text" name="adminname"  placeholder="name" /></h6>
					<h6><input type="passwords" name="adminpass" placeholder="password" /></h6>
					<h6><input type="passwords" name="adminconfirmpass" placeholder="confirm password" /></h6>
					<input type="submit" name="adminsubmitbutton" value="Submit"/>
					
				</td>
			</tr>

		
			</table>
		
	</form>
	
</body>
</html>
<?php
	session_start();
	if(!isset($_SESSION['adminid'])){
		header('Location: adminloginform.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: white;">
	
	<div style="text-align: center;">
		<a href="adminlogout.php"><input type="submit" name="adminlogoutbutton" value="Logout" style="font-size: 50px; color: red; background-color: skyblue;" /></a>
		<hr/>
	</div>
	<table style="border: none; width: 1000px;">
		<tr>
			<td></td>
			<td style="width: 650px; text-align: center;">
				<h3><a href="sellerinfovisiting.php" style="text-decoration: none;">Seller Info</a></h3>
				<h3><a href="productinfovisiting.php" style="text-decoration: none;">Product Info</a></h3>
				<h3><a href="customerinfovisiting.php" style="text-decoration: none;">Customer Info</a></h3>
				<h4><a href="orderinfovisiting.php" style="text-decoration: none;">Order Info</a></h4>
			</td>
		</tr>
	</table>
	
</body>
</html>
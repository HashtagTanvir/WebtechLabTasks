<?php
if(isset($_REQUEST['adminsubmitbutton'])){

	$id=trim($_REQUEST['adminid']);
	$name=trim($_REQUEST['adminname']);
	$pass=trim($_REQUEST['adminpass']);
	$cpass=trim($_REQUEST['adminconfirmpass']);
	if(empty($id) == true || empty($name) == true || empty($pass)==true||empty($cpass)==true){
			echo "null submission";
	}else{
		if($pass==$cpass){
			$con=mysqli_connect('localhost','root','','databasedemo');
			$sql="INSERT INTO admininf VALUES('".$id."','".$name."','".$pass."','".$cpass."')";
			if(!$con){
				die("connenction failed: ".$mysqli_connect_error());
			}
			if (mysqli_query($con,$sql)){
				echo "Record Save Successfully";
			}else{
				echo "Error: ". $sql."<br/>".mysqli_error($con);
			}
			mysqli_close($con);
		}else{
			echo "Password and Confirm Password should be same";
		}
		
	}
	
}
if(isset($_POST['adminloginbutton'])){

	$adminid=trim($_POST['adminid']);
	$adminpass=trim($_POST['adminpass']);
	$con2=mysqli_connect('localhost','root','','databasedemo');
	$sql2="SELECT id FROM admininf WHERE id='".$adminid."'";
	$result=mysqli_query($con2,$sql2);
	if(!$con2){
		die("connenction failed: ".$mysqli_connect_error());
	}
	if(mysqli_num_rows($result)==1){
		session_start();
		$_SESSION['adminid']=$adminid;
		if(isset($_SESSION['adminid'])){
			header('Location: adminsettings.php');
		}
	}
	else{
		echo "Id is not correct";
	}
	mysqli_close($con2);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="regivalidation.php">
		<fieldset style="width: 150px">
			<legend>REGISTRATION</legend>
			<table style="border: none;">
				<tr>
					<td></td>
					<td style="border: none; width: 150px; text-align: left;">
						ID<br/>
						<input type="text" name="idtext" placeholder="id" /><br/>
						Password<br/>
						<input type="text" name="passtext" placeholder="password" /><br/>
						Confirm Password<br/>
						<input type="text" name="cpasstext" placeholder="confirm password" /><br/>
						Name<br/>
						<input type="text" name="nametext" placeholder="name" /><br/>
						Email<br/>
						<input type="text" name="emailtext" placeholder="email" /><br/>
						User Type[User/Admin]<br/>
						<select name="usertype">
							<option value="user">User</option>
							<option value="admin">Admin</option>
						</select><hr/>
						<a href="regivalidation.php"></a><input type="submit" name="registerbut" value="Register">
						<a href="login.php">Login</a>
					</td>
				</tr>
			</table>

		</fieldset>
		
	</form>
</body>
</html>
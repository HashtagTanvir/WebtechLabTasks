<?php
if(isset($_REQUEST['registerbut'])){
	$id=trim($_REQUEST['idtext']);
	$pass=trim($_REQUEST['passtext']);
	$cpass=trim($_REQUEST['cpasstext']);
	$name=trim($_REQUEST['nametext']);
	$email=trim($_REQUEST['emailtext']);
	$type=trim($_REQUEST['usertype']);
	if(empty($id) == true || empty($pass) == true || empty($cpass)==true||empty($name)==true||empty($email)==true||empty($type)==true){
			echo "null submission";
	}
	else{
		if($pass==$cpass){
			$con=mysqli_connect('localhost','root','','miniprojectdb');
			$sql="INSERT INTO validation VALUES('".$id."','".$pass."','".$cpass."','".$name."','".$email."','".$type."')";
			if(!$con){
				die("connenction failed: ".$mysqli_connect_error());
			}
			if (mysqli_query($con,$sql)){
				echo "Record Save Successfully";
			}else{
				echo "Error: ". $sql."<br/>".mysqli_error($con);
			}
			mysqli_close($con);
		}
		else{
			echo "Password is incorrect";
		}
	}
}

if(isset($_REQUEST['registerbutton'])){
	$uid=trim($_REQUEST['uidtext']);
	$upass=trim($_REQUEST['upasstext']);
	if(empty($uid)==true||empty($upass)==true){
		echo "null submission";
	}
	else
	{
		$con2=mysqli_connect('localhost','root','','miniprojectdb');
		$sql2="SELECT type FROM validation WHERE id='".$uid."'";
		$result=mysqli_query($con2,$sql2);
		if(!$con2){
			die("connenction failed: ".$mysqli_connect_error());
		}
		if(mysqli_num_rows($result)==1){
			while ($row=mysqli_fetch_assoc($result)){
				$usertype=current($row);
				if($usertype=="admin"){

				}
				if($usertype=="user"){
				}

			}
		}
		else{
			echo "Id is not correct";
		}
		mysqli_close($con2);
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="regivalidation.php">
		<fieldset style="width: 150px">
			<legend>LOGIN</legend>
			<table style="border: none;">
				<tr>
					<td></td>
					<td style="border: none; width: 150px; text-align: left;">
						User ID<br/>
						<input type="text" name="uidtext" placeholder="id" /><br/>
						Password<br/>
						<input type="text" name="upasstext" placeholder="password" /><br/><hr/>
						
						<a href="regivalidation.php"></a><input type="submit" name="registerbutton" value="Login">
						<a href="regi.php">Register</a>
					</td>
				</tr>
			</table>

		</fieldset>
		
	</form>
</body>
</html>
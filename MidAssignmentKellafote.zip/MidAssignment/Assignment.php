<?php 

	if(isset($_POST["submit"])){
		$firstname= trim($_POST["fname"]);
		$lastname= trim($_POST["lname"]);
		$phone=trim($_POST["phone"]);
		$email=trim($_POST["email"]);
		$password=trim($_POST["pass"]);
		$confirmpassword=trim($_POST["cpass"]);
		$gender=trim($_POST["gender"]);
		$dob=trim($_POST["dob"]);
		$myfile=fopen("tanvir.text", "w") or die("Unable to Open file!");
		fwrite($myfile, $firstname);
		fwrite($myfile, $lastname);
		fwrite($myfile, $dob);
		fwrite($myfile, $gender);
		fwrite($myfile, $phone);
		fwrite($myfile, $email);
		fwrite($myfile, $password);
		fwrite($myfile, $confirmpassword);

	}	 
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Mid Assignment</title>
</head>
<body>
	<form method="post">
		<table style="width: 500px; border-style: none;">
		<tr>
			<td style="width: 200px; border-style: none;">
				First Name:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="text" name="fname" required="required" pattern="[A-Za-z]+[A-Za-z0-9]+">
				
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Last Name:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="text" name="lname" required="required">
					
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				DOB:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="date" name="dob" required="required">
					
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Gender:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="radio" name="gender" value="Male"  required="required"/> Male 
				<input type="radio" name="gender" value="Female" required="required"/> Female 
				<input type="radio" name="gender" value="Other"   required="required"/> Other 
				
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Phone:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="text" name="phone" required="required">
					
				
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Email ID:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="text" name="email" required="required" pattern="[A-Za-z0-9_%+-.]+@[A-Za-z0-9]+[.]+com$">
					
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Password:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="password" name="pass" required="required">
					
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				Confirm Password:
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="password" name="cpass" required="required">
					
			</td>
		</tr>
		<tr>
			<td style="width: 200px; border-style: none;">
				
			</td>
			<td style="width: 300px; border-style: none;">
				
				<input type="submit" name="submit" required="required">
					
			</td>
		</tr>
		</table>
	</form>
	
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>PORFOLIO</title>
</head>
<body style="background-color: skyblue;">
	
		<fieldset style="border: double;width: 1000px; color: blue;">
			<legend>
				Project Portfolio
			</legend>
			<table style="border: none; width: 1000px">
			<tr>
				<th style="background-color: green;"><b style="color: black;">Project Name</b></th>
				<th style="background-color: green;"><b style="color: black;">Semester</b></th>
				<h2><th style="background-color: green;"><b style="color: black;">Duration</b></th></h2>
				<th style="background-color: green;"><b style="color: black;">Faculty</b></th>
			</tr>
			<tr>
				<td>Employee Management System</td>
				<td>2016-2017, Spring</td>
				<td>4 Month</td>
				<td>Ezazul Haque</td>
			</tr>
			<tr>
				<td>Library Management System</td>
				<td>2017-2018, Summer</td>
				<td>4 Month</td>
				<td>Zahid Uddin Ahmed</td>
			</tr>
			<tr>
				<td>E-Commerce System</td>
				<td>2018-2019, Fall</td>
				<td></td>
				<td>MD AL-AMIN</td>
			</tr>
			</table>
		</fieldset>
</body>
</html>
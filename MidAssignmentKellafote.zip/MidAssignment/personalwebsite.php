<!DOCTYPE html>
<html>
<head>
	<title>My Information</title>
</head>
<body style="background-color: skyblue;">
	<table style="border: none; width: 100%; background-color: none ">
		<tr>
			<td style="border: none; width: 100%;">
				<a href="https://www.youtube.com/watch?v=Rxr6ubbJto0"><img src="fifa.jpg" alt="http://www.facebook.com" width="100%" height="500" /></a>
			</td>
		</tr>
	</table>
	<table  style="border: none;width: 1000px;">
		<tr>
			<td style="border: none; width: 500px;">
				
			</td>
			<td style="border: none; width: 500px; background-color: none; text-align: left;">
				<h3><a href="aboutme.php" style="color: blue;"><u><b>About Me</b></u></a></h3>
				<h3><a href="Portfolio.php" style="color: blue;"><u><b>Portfolio</b></u></a></h3>
			</td>
			
		</tr>
	</table>
</body>
</html>

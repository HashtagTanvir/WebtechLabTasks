<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body style="background-color: skyblue;">
	<table style="border: none;width: 1000px;">
		<tr style="border: none;">
			<td style="border: none; width: 500px;">
				
			</td>
			<td style="border: none; width: 500px; background-color: none; text-align: left;">
				<h1><i style="color: red">Hey! I'm Tanvir</i></h1>
			</td>
		</tr>
	</table>
	<table style="border: none; width: 1000px">
		<tr>
			<td>
				
			</td>
			<td><img src="iamtanvir.jpg" width="200" height="200"></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Program: </b></td>
			<td style=" border: none;"><b>Bachelor of Science in Computer Science</b></td>
			<td style="border: none;"></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Department: </b></td>
			<td style=" border: none;"><b>FACULTY OF SCIENCE & INFORMATION TECHNOLOGY</b></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Nationality: </b></td>
			<td style=" border: none;"><b>Bangladesh</b></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Phone: </b></td>
			<td style=" border: none;"><b>01779825746</b></td>
			<td style="border: none;"></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Email: </b></td>
			<td style=" border: none;"><b><u>ahmedtanvir.edu@gmail.com</u></b></td>
			<td style="border: none;"></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>DOB: </b></td>
			<td style=" border: none;"><b>03/31/1996</b></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Sex: </b></td>
			<td style=" border: none;"><b>Male</b></td>
		</tr>
		<tr>
			<td style=" border: none; text-align: right;"><b>Nationality: </b></td>
			<td style=" border: none;"><b>Bangladesh</b></td>
		</tr>
	
</body>
</html>
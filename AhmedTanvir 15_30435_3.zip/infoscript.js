function NameValidation(form){
	var n=document.getElementById('nid').value;
	if(n == ""){
		alert('Name cannot be empty');
	}
}
function EmailValidation(){
	var e=document.getElementById('eid').value;
	if(e == ""){
		alert('Email cannot be empty');
	}
	
}
function DOBvalidaiton(){
	var dd=document.getElementById('ddid').value;
	var mm=document.getElementById('mmid').value;
	var yyyy=document.getElementById('yyyyid').value;
	var matchingvalue=/[A-Za-z]/g;
	if(dd.match(matchingvalue)||mm.match(matchingvalue)||yyyy.match(matchingvalue)){
		alert('DOB should be numebr');
	}
	else{
		if(dd.length > 2){
			alert('Day cannot be more than two numebr');
		}
		if(mm.length > 2){
			alert('Month cannot be more than two numebr');
		}
		if(yyyy.length > 4){
			alert('Year cannot be more than four numebr');
		}
	}
	

}
function OtherValidation(form){
	ErrorText= "";
	if(form.nametext.value == ""){
		alert('Name cannot be empty');
		return false;
	}
	if(form.emailtext.value == ""){
		alert('Email cannot be empty');
		return false;
	}
	if(form.ddname.value == ""||form.mmname.value == ""||form.yyyyname.value == ""){
		alert('Pelase Enter Your birth date');
		return false;
	}
	if ( ( form.gender[0].checked == false ) && ( form.gender[1].checked == false ) )
	{
		alert ( "Please choose your Gender: Male or Female" );
		return false;
	}
	if ( ( form.degree[0].checked == false ) && ( form.degree[1].checked == false ) )
	{
		alert ( "Please choose your Degree" );
		return false;
	}
	if(form.photofile.value == ""){
		alert('file have to be uploaded');
	}
	if (ErrorText= ""){
		form.submit();
	}

	
}